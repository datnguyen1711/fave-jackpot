import React from "react";

const Card = ({ card, flipped }) => {
  return (
    <div
      className={`gamePlay-cardItem ${card.hihi ? "visible" : ""}`}
      key={card.id}
    >
      <div className={flipped ? "flipped" : ""}>
        <img
          src={card.hiddenCard}
          style={{ width: "80px" }}
          alt=""
          className="back"
        />
        <img src={card.cardSrc} alt="" className="front" />
      </div>
    </div>
  );
};

export default Card;
