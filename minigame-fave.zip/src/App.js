import "./App.css";
import GamePlay from "./pages/GamePlay/GamePlay";
import PreGame from "./pages/Pregame/PreGame";

function App() {
  return (
    <div className="App">
      {/* <PreGame /> */}
      <GamePlay />
    </div>
  );
}

export default App;
