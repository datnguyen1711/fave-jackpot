import React, { useState, useEffect } from "react";
import "./GamePlay.scss";
import btnClose from "../../assets/images/main/close-button.png";
import faveTittle from "../../assets/images/main/fave-tittle.png";
import Reward from "../../components/Reward/Reward";

import card50 from "../../assets/images/cards/50Tile.png";
import card100 from "../../assets/images/cards/100Tile.png";
import card500 from "../../assets/images/cards/500Tile.png";
import card1000 from "../../assets/images/cards/1000Tile.png";
import card5000 from "../../assets/images/cards/5000Tile.png";
import cardNo from "../../assets/images/cards/noReward.png";
import Card from "../../components/Card/Card";
import hiddenCard from "../../assets/images/cards/hiddenCard.png";
import movingCard from "../../assets/images/cards/movingCard.png";

const GamePlay = () => {
  const [flipped, setFlipped] = useState(false);
  const [itemRandom, setItemRandom] = useState({ id: 0 });
  const [randoming, setRandoming] = useState({});
  const [stop, setStop] = useState(false);
  const [state, setState] = useState([
    { id: 1, cardSrc: card50, hiddenCard: hiddenCard },
    { id: 2, cardSrc: card100, hiddenCard: hiddenCard },
    { id: 3, cardSrc: card1000, hiddenCard: hiddenCard },
    { id: 4, cardSrc: cardNo, hiddenCard: hiddenCard },
    { id: 5, cardSrc: card50, hiddenCard: hiddenCard },
    { id: 6, cardSrc: card500, hiddenCard: hiddenCard },
    { id: 7, cardSrc: card5000, hiddenCard: hiddenCard },
    { id: 8, cardSrc: card50, hiddenCard: hiddenCard },
    { id: 9, cardSrc: cardNo, hiddenCard: hiddenCard },
  ]);
  const playGame = () => {
    setFlipped(!flipped);
  };
  const stopGame = () => {
    setStop(true);
    state.map((item) =>
      item.hiddenCard !== movingCard ? (item.hihi = "visible") : false
    );
  };

  const shuffle = (array) => {
    let currentIndex = array.length,
      randomIndex;

    while (currentIndex != 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;

      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex],
        array[currentIndex],
      ];
    }

    setState(array);
    return array;
  };

  useEffect(() => {
    if (flipped === false) {
      let abc = state
        .map((value) => ({ value, sort: Math.random() }))
        .sort((a, b) => a.sort - b.sort)
        .map(({ value }) => value);
      setTimeout(() => {
        setState(abc);
      }, 2000);
    } else {
      const ran = setTimeout(() => {
        if (stop === true) {
          clearInterval(ran);
        } else {
          state.map((obj) => {
            obj.hiddenCard = hiddenCard;
          });
          let randomItem = state[Math.floor(Math.random() * state.length)];
          setRandoming(randomItem);
          let objIndex = state.findIndex(
            (obj) => obj.cardSrc == randomItem.cardSrc
          );

          if (randomItem.id === itemRandom.id) {
            let randomItem1 = state[Math.floor(Math.random() * state.length)];
            state[objIndex].hiddenCard = movingCard;
            setItemRandom(randomItem1);
          } else {
            state[objIndex].hiddenCard = movingCard;
            setItemRandom(randomItem);
          }
        }
      }, 500);
    }
  }, [state, itemRandom]);
  return (
    <div className="main">
      <div className="gamePlay">
        <div className="gamePlay-top">
          <div className="header">
            <div className="header-close">
              <img src={btnClose} alt="" />
            </div>
            <div className="header-title">
              <img src={faveTittle} alt="" />
            </div>
            <div className="div"></div>
          </div>
          <Reward />
        </div>
        <div className="gamePlay-main">
          <div className="gamePlay-main-title">
            <div className="line"></div>
            <div className="title">PLAY TO WIN </div>
          </div>
          <div className="gamePlay-cardGrid">
            {state.map((card) => (
              <Card card={card} flipped={flipped} />
            ))}
          </div>
        </div>
        <div className="button-click">
          <button onClick={flipped ? stopGame : playGame}>
            {flipped ? "Stop" : "Play"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default GamePlay;
