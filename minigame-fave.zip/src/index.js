import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import "./index.css";
import App from "./App";
import { CustomRouter } from "./components/CustomRouter/CustomRouter";
import history from "./components/History/History";



ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      {/* <CustomRouter history={history}> */}
      <App />
      {/* </CustomRouter> */}
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById("root")
);
